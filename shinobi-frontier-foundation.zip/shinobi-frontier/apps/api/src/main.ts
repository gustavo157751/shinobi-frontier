import 'reflect-metadata';
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
async function bootstrap() {
 const app = await NestFactory.create(AppModule);
 app.setGlobalPrefix('api');
 app.enableCors({ origin: process.env.WEB_ORIGIN ?? 'http://localhost:5173', credentials: true });
 app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));
 await app.listen(process.env.API_PORT ?? 3000);
}
bootstrap();
